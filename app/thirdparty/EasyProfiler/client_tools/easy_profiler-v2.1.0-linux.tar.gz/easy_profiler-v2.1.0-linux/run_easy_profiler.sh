#!/bin/bash

#########################################################################
#Script Name:   run_easy_profiler.sh
#Description:   Run EasyProfiler app under docker on linux
#Version:       1.0
#Authors:       Lukasz Uszko (lukasz.uszko@aptiv.com)
#Copyright:     (C) 2022 APTIV, All Rights Reserved.
#########################################################################

DOCKER_IMG=easy_profiler
DOCKER_TAG=latest
EASY_PROFILER_VERSION=2.1.0

# Search for docker image
image_query=$( docker images -q "${DOCKER_IMG}":"${DOCKER_TAG}" )

if [[ -n "${image_query}" ]]; then
    echo "Docker image: ["${DOCKER_IMG}":"${DOCKER_TAG}"] exists"
else
    echo "Docker image ["${DOCKER_IMG}":"${DOCKER_TAG}"] doesn't exist, start building: [${DOCKER_IMG}:${DOCKER_TAG}] image"
    docker build	-t ${DOCKER_IMG}:${DOCKER_TAG}            \
                    --build-arg VERSION=${EASY_PROFILER_VERSION} \
                    -f Dockerfile_${DOCKER_IMG} \
                    .
    echo ">>> Docker image: ${DOCKER_IMG}:${DOCKER_TAG} has been built successfully! <<<"
fi

echo ">>> Running ${DOCKER_IMG}:${DOCKER_TAG}... <<<"

docker run \
  --name "easy_profiler_gui" \
  --rm \
  --security-opt apparmor=unconfined \
  --net=host \
  --env DISPLAY="$DISPLAY" \
  --volume "/tmp/.X11-unix:/tmp/.X11-unix:ro" \
  easy_profiler:latest \
  profiler_gui